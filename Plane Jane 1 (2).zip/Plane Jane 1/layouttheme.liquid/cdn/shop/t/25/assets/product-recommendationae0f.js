/** Shopify CDN: Minification failed

Line 16:23 Transforming let to the configured target environment ("es5") is not supported yet
Line 16:186 Transforming let to the configured target environment ("es5") is not supported yet
Line 16:325 Transforming let to the configured target environment ("es5") is not supported yet
Line 16:375 Transforming let to the configured target environment ("es5") is not supported yet
Line 16:529 Transforming let to the configured target environment ("es5") is not supported yet
Line 16:585 Transforming let to the configured target environment ("es5") is not supported yet
Line 16:635 Transforming let to the configured target environment ("es5") is not supported yet
Line 16:777 Transforming let to the configured target environment ("es5") is not supported yet
Line 16:890 Transforming let to the configured target environment ("es5") is not supported yet
Line 16:946 Transforming let to the configured target environment ("es5") is not supported yet
... and 1 more hidden warnings

**/
if(Shopify.designMode){let e=document.querySelector(".product-recommendations");document.addEventListener("shopify:section:load",function(t){console.log("IN DESIGN MODE"),console.log(e);let r=document.querySelector(".product-recommendations"),n=e.dataset.url;console.log(n),fetch(n).then(e=>e.text()).then(e=>{console.log(e);let t=document.createElement("div");t.innerHTML=e;let n=t.querySelector(".product-recommendations");console.log(n),n&&n.innerHTML.trim().length&&(r.innerHTML=n.innerHTML)}).catch(e=>{console.error(e)})});let t=e.dataset.url;fetch(t).then(e=>e.text()).then(t=>{let r=document.createElement("div");r.innerHTML=t;let n=r.querySelector(".product-recommendations");n&&n.innerHTML.trim().length&&(e.innerHTML=n.innerHTML)}).catch(e=>{console.error(e)})}else{let r=document.querySelector(".product-recommendations"),n=(e,t)=>{if(!e[0].isIntersecting)return;t.unobserve(r);let n=r.dataset.url;fetch(n).then(e=>e.text()).then(e=>{let t=document.createElement("div");t.innerHTML=e;let n=t.querySelector(".product-recommendations");n&&n.innerHTML.trim().length&&(r.innerHTML=n.innerHTML)}).catch(e=>{console.error(e)})},o=new IntersectionObserver(n,{rootMargin:"0px 0px 200px 0px"});o.observe(r)}