
var eventHandled = 2;


!(function () {
    "use strict";
    var e = function (e, t, r) {
            return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
        },
        t = document.createComment("UdeslyEventBus");
    document.body.append(t);
    class r {
        on(e, r) {
            t.addEventListener(e, (e) => {
                r(e.detail);
            });
        }
        dispatch(e, r) {
            t.dispatchEvent(new CustomEvent(e, { detail: r }));
        }
    }
    if (Array.isArray(window.Udesly)) {
        var a = window.Udesly;
        (window.Udesly = new r()), a.forEach((e) => e());
    } else window.Udesly = new r();
    var n = window.UdeslyConfigurationErrors || [];
    if (n.length) {
        var i = document.createElement("link");
        (i.rel = "stylesheet"), (i.href = "https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css"), document.head.append(i);
        var o = document.createElement("script");
        (o.src = "https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"),
            (o.onload = function () {
                var e = new Notyf({ duration: 2e5, dismissible: !0 });
                n.forEach((t) => {
                    e.error(t);
                });
            }),
            document.body.append(o);
    }
    function s(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : document;
        return t.querySelectorAll('[data-node-type="'.concat(e, '"]'));
    }
    function c(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : document;
        return t.querySelector('[data-node-type="'.concat(e, '"]'));
    }
    function l(e, t, r, a, n, i, o) {
        try {
            var s = e[i](o),
                c = s.value;
        } catch (e) {
            return void r(e);
        }
        s.done ? t(c) : Promise.resolve(c).then(a, n);
    }
    var d = function (e) {
        return function () {
            var t = this,
                r = arguments;
            return new Promise(function (a, n) {
                var i = e.apply(t, r);
                function o(e) {
                    l(i, a, n, o, s, "next", e);
                }
                function s(e) {
                    l(i, a, n, o, s, "throw", e);
                }
                o(void 0);
            });
        };
    };
    function u(e) {
        "string" == typeof e && (e = e.replace(".", ""));
        var t,
            r,
            a = "",
            n = /\{\{\s*(\w+)\s*\}\}/,
            i = document.documentElement.getAttribute("data-money-format") || "${{amount}}";
        function o(e, t) {
            return void 0 === e ? t : e;
        }
        function s(e, t, r, a) {
            if (((t = o(t, 2)), (r = o(r, ",")), (a = o(a, ".")), isNaN(e) || null == e)) return 0;
            var n = (e = (e / 100).toFixed(t)).split(".");
            return n[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1" + r) + (n[1] ? a + n[1] : "");
        }
        switch (i.match(n)[1]) {
            case "amount":
                a = s(e, 2);
                break;
            case "amount_no_decimals":
                a = s(e, 0);
                break;
            case "amount_with_comma_separator":
                a = s(e, 2, ".", ",");
                break;
            case "amount_no_decimals_with_comma_separator":
                a = s(e, 0, ".", ",");
        }
        return (t = i.replace(n, a)), ((r = document.createElement("textarea")).innerHTML = t), r.value;
    }
    "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self && self;
    var p,
        m,
        h =
            ((function (e, t) {
                !(function (e) {
                    function t(e) {
                        var r,
                            a,
                            n = new Error(e);
                        return (r = n), (a = t.prototype), Object.setPrototypeOf ? Object.setPrototypeOf(r, a) : (r.__proto__ = a), n;
                    }
                    function r(e, r, a) {
                        var n = r.slice(0, a).split(/\n/),
                            i = n.length,
                            o = n[i - 1].length + 1;
                        throw t((e += " at line " + i + " col " + o + ":\n\n  " + r.split(/\n/)[i - 1] + "\n  " + Array(o).join(" ") + "^"));
                    }
                    t.prototype = Object.create(Error.prototype, { name: { value: "Eta Error", enumerable: !1 } });
                    var a = new Function("return this")().Promise;
                    function n(e, t) {
                        for (var r in t) (a = t), (n = r), Object.prototype.hasOwnProperty.call(a, n) && (e[r] = t[r]);
                        var a, n;
                        return e;
                    }
                    function i(e, t, r, a) {
                        var n, i;
                        return (
                            Array.isArray(t.autoTrim) ? ((n = t.autoTrim[1]), (i = t.autoTrim[0])) : (n = i = t.autoTrim),
                            (r || !1 === r) && (n = r),
                            (a || !1 === a) && (i = a),
                            i || n
                                ? "slurp" === n && "slurp" === i
                                    ? e.trim()
                                    : ("_" === n || "slurp" === n
                                          ? (e = (function (e) {
                                                return String.prototype.trimLeft ? e.trimLeft() : e.replace(/^\s+/, "");
                                            })(e))
                                          : ("-" !== n && "nl" !== n) || (e = e.replace(/^(?:\r\n|\n|\r)/, "")),
                                      "_" === i || "slurp" === i
                                          ? (e = (function (e) {
                                                return String.prototype.trimRight ? e.trimRight() : e.replace(/\s+$/, "");
                                            })(e))
                                          : ("-" !== i && "nl" !== i) || (e = e.replace(/(?:\r\n|\n|\r)$/, "")),
                                      e)
                                : e
                        );
                    }
                    var o = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
                    function s(e) {
                        return o[e];
                    }
                    var c = /`(?:\\[\s\S]|\${(?:[^{}]|{(?:[^{}]|{[^}]*})*})*}|(?!\${)[^\\`])*`/g,
                        l = /'(?:\\[\s\w"'\\`]|[^\n\r'\\])*?'/g,
                        d = /"(?:\\[\s\w"'\\`]|[^\n\r"\\])*?"/g;
                    function u(e) {
                        return e.replace(/[.*+\-?^${}()|[\]\\]/g, "\\$&");
                    }
                    function p(e, t) {
                        var a = [],
                            n = !1,
                            o = 0,
                            s = t.parse;
                        if (t.plugins) for (var p = 0; p < t.plugins.length; p++) (x = t.plugins[p]).processTemplate && (e = x.processTemplate(e, t));
                        function m(e, r) {
                            e && (e = i(e, t, n, r)) && ((e = e.replace(/\\|'/g, "\\$&").replace(/\r\n|\n|\r/g, "\\n")), a.push(e));
                        }
                        t.rmWhitespace && (e = e.replace(/[\r\n]+/g, "\n").replace(/^\s+|\s+$/gm, "")), (c.lastIndex = 0), (l.lastIndex = 0), (d.lastIndex = 0);
                        for (
                            var h,
                                f = [s.exec, s.interpolate, s.raw].reduce(function (e, t) {
                                    return e && t ? e + "|" + u(t) : t ? u(t) : e;
                                }, ""),
                                y = new RegExp("([^]*?)" + u(t.tags[0]) + "(-|_)?\\s*(" + f + ")?\\s*", "g"),
                                v = new RegExp("'|\"|`|\\/\\*|(\\s*(-|_)?" + u(t.tags[1]) + ")", "g");
                            (h = y.exec(e));

                        ) {
                            o = h[0].length + h.index;
                            var w = h[1],
                                g = h[2],
                                b = h[3] || "";
                            m(w, g), (v.lastIndex = o);
                            for (var E = void 0, S = !1; (E = v.exec(e)); ) {
                                if (E[1]) {
                                    var _ = e.slice(o, E.index);
                                    (y.lastIndex = o = v.lastIndex), (n = E[2]), (S = { t: b === s.exec ? "e" : b === s.raw ? "r" : b === s.interpolate ? "i" : "", val: _ });
                                    break;
                                }
                                var A = E[0];
                                if ("/*" === A) {
                                    var C = e.indexOf("*/", v.lastIndex);
                                    -1 === C && r("unclosed comment", e, E.index), (v.lastIndex = C);
                                } else
                                    "'" === A
                                        ? ((l.lastIndex = E.index), l.exec(e) ? (v.lastIndex = l.lastIndex) : r("unclosed string", e, E.index))
                                        : '"' === A
                                        ? ((d.lastIndex = E.index), d.exec(e) ? (v.lastIndex = d.lastIndex) : r("unclosed string", e, E.index))
                                        : "`" === A && ((c.lastIndex = E.index), c.exec(e) ? (v.lastIndex = c.lastIndex) : r("unclosed string", e, E.index));
                            }
                            S ? a.push(S) : r("unclosed tag", e, h.index + w.length);
                        }
                        if ((m(e.slice(o, e.length), !1), t.plugins))
                            for (p = 0; p < t.plugins.length; p++) {
                                var x;
                                (x = t.plugins[p]).processAST && (a = x.processAST(a, t));
                            }
                        return a;
                    }
                    function m(e, t) {
                        var r = p(e, t),
                            a =
                                "var tR='',__l,__lP" +
                                (t.include ? ",include=E.include.bind(E)" : "") +
                                (t.includeFile ? ",includeFile=E.includeFile.bind(E)" : "") +
                                "\nfunction layout(p,d){__l=p;__lP=d}\n" +
                                (t.useWith ? "with(" + t.varName + "||{}){" : "") +
                                (function (e, t) {
                                    for (var r = 0, a = e.length, n = ""; r < a; r++) {
                                        var i = e[r];
                                        if ("string" == typeof i) n += "tR+='" + i + "'\n";
                                        else {
                                            var o = i.t,
                                                s = i.val || "";
                                            "r" === o
                                                ? (t.filter && (s = "E.filter(" + s + ")"), (n += "tR+=" + s + "\n"))
                                                : "i" === o
                                                ? (t.filter && (s = "E.filter(" + s + ")"), t.autoEscape && (s = "E.e(" + s + ")"), (n += "tR+=" + s + "\n"))
                                                : "e" === o && (n += s + "\n");
                                        }
                                    }
                                    return n;
                                })(r, t) +
                                (t.includeFile
                                    ? "if(__l)tR=" + (t.async ? "await " : "") + "includeFile(__l,Object.assign(" + t.varName + ",{body:tR},__lP))\n"
                                    : t.include
                                    ? "if(__l)tR=" + (t.async ? "await " : "") + "include(__l,Object.assign(" + t.varName + ",{body:tR},__lP))\n"
                                    : "") +
                                "if(cb){cb(null,tR)} return tR" +
                                (t.useWith ? "}" : "");
                        if (t.plugins)
                            for (var n = 0; n < t.plugins.length; n++) {
                                var i = t.plugins[n];
                                i.processFnString && (a = i.processFnString(a, t));
                            }
                        return a;
                    }
                    var h = new ((function () {
                            function e(e) {
                                this.cache = e;
                            }
                            return (
                                (e.prototype.define = function (e, t) {
                                    this.cache[e] = t;
                                }),
                                (e.prototype.get = function (e) {
                                    return this.cache[e];
                                }),
                                (e.prototype.remove = function (e) {
                                    delete this.cache[e];
                                }),
                                (e.prototype.reset = function () {
                                    this.cache = {};
                                }),
                                (e.prototype.load = function (e) {
                                    n(this.cache, e);
                                }),
                                e
                            );
                        })())({}),
                        f = {
                            async: !1,
                            autoEscape: !0,
                            autoTrim: [!1, "nl"],
                            cache: !1,
                            e: function (e) {
                                var t = String(e);
                                return /[&<>"']/.test(t) ? t.replace(/[&<>"']/g, s) : t;
                            },
                            include: function (e, r) {
                                var a = this.templates.get(e);
                                if (!a) throw t('Could not fetch template "' + e + '"');
                                return a(r, this);
                            },
                            parse: { exec: "", interpolate: "=", raw: "~" },
                            plugins: [],
                            rmWhitespace: !1,
                            tags: ["<%", "%>"],
                            templates: h,
                            useWith: !1,
                            varName: "it",
                        };
                    function y(e, t) {
                        var r = {};
                        return n(r, f), t && n(r, t), e && n(r, e), r;
                    }
                    function v(e, r) {
                        var a = y(r || {}),
                            n = a.async
                                ? (function () {
                                      try {
                                          return new Function("return (async function(){}).constructor")();
                                      } catch (e) {
                                          throw e instanceof SyntaxError ? t("This environment doesn't support async/await") : e;
                                      }
                                  })()
                                : Function;
                        try {
                            return new n(a.varName, "E", "cb", m(e, a));
                        } catch (r) {
                            throw r instanceof SyntaxError ? t("Bad template syntax\n\n" + r.message + "\n" + Array(r.message.length + 1).join("=") + "\n" + m(e, a) + "\n") : r;
                        }
                    }
                    function w(e, t) {
                        if (t.cache && t.name && t.templates.get(t.name)) return t.templates.get(t.name);
                        var r = "function" == typeof e ? e : v(e, t);
                        return t.cache && t.name && t.templates.define(t.name, r), r;
                    }
                    function g(e, r, n, i) {
                        var o = y(n || {});
                        if (!o.async) return w(e, o)(r, o);
                        if (!i) {
                            if ("function" == typeof a)
                                return new a(function (t, a) {
                                    try {
                                        t(w(e, o)(r, o));
                                    } catch (e) {
                                        a(e);
                                    }
                                });
                            throw t("Please provide a callback function, this env doesn't support Promises");
                        }
                        try {
                            w(e, o)(r, o, i);
                        } catch (e) {
                            return i(e);
                        }
                    }
                    (e.compile = v),
                        (e.compileToString = m),
                        (e.config = f),
                        (e.configure = function (e) {
                            return n(f, e);
                        }),
                        (e.defaultConfig = f),
                        (e.getConfig = y),
                        (e.parse = p),
                        (e.render = g),
                        (e.renderAsync = function (e, t, r, a) {
                            return g(e, t, Object.assign({}, r, { async: !0 }), a);
                        }),
                        (e.templates = h),
                        Object.defineProperty(e, "__esModule", { value: !0 });
                })(t);
            })((p = { exports: {} }), p.exports),
            p.exports),
        f = (m = h) && m.__esModule && Object.prototype.hasOwnProperty.call(m, "default") ? m.default : m;
    function y(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var a = Object.getOwnPropertySymbols(e);
            t &&
                (a = a.filter(function (t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })),
                r.push.apply(r, a);
        }
        return r;
    }
    var v;


  
    class w {
        constructor(e) {
            (this.wrapper = e),
                (this.templateFunc = f.compile(this.wrapper.querySelector('script[type="text/x-wf-template"]').textContent, { autoEscape: !1 })),
                this.init(),
                (this.emptyState = this.wrapper.querySelector(".w-commerce-commercecartemptystate")),
                (this.cartList = this.wrapper.querySelector(".w-commerce-commercecartlist")),
                (this.cartListWrapper = this.wrapper.querySelector("[data-node-type='commerce-cart-form']"));
        }
                        
        init() {
            var e = this;
            this.wrapper.addEventListener("wf-change-cart-state", (e) => {
                this.handleChangeCartState(e);
            }),
                (this.openOnProductAdded = this.wrapper.hasAttribute("data-open-product")),
                (this.openOnHover = this.wrapper.hasAttribute("data-open-on-hover")),
                (this.closeLink = c("commerce-cart-close-link", this.wrapper)),
                (this.openLink = c("commerce-cart-open-link", this.wrapper)),
                (this.cartContainer = c("commerce-cart-container", this.wrapper)),
                (this.cartContainerWrapper = c("commerce-cart-container-wrapper", this.wrapper)),
                (this.form = c("commerce-cart-form", this.wrapper)),
                this.closeLink && (this.closeLink.addEventListener("click", () => this.toggleCart()), this.closeLink.addEventListener("tap", () => this.toggleCart())),
                this.openLink &&
                    (this.openLink.removeAttribute("href"),
                    this.openOnHover
                        ? (this.openLink.addEventListener("mouseenter", () => this.openCart()), this.cartContainer && this.cartContainer.addEventListener("mouseleave", () => this.closeCart()))
                        : (this.openLink.addEventListener("click", () => this.toggleCart()), this.openLink.addEventListener("tap", () => this.toggleCart()))),
                this.updateCartCount(),
                Udesly.on(
                    "product-added",
                    (function () {
                        var t = d(function* (t) {
                          console.log(eventHandled); 
                          if (eventHandled % 2 == 0) {
                            eventHandled = eventHandled + 1; 
                            yield e.updateCart(), e.openOnProductAdded && t && e.openCart();
                          }
                        });

                      
                        return function (e) {
                            return t.apply(this, arguments);
                        };
                    })()
                ),
                this.form.addEventListener(
                    "change",
                    (function () {
                        var t = d(function* (t) {
                            t.target.matches('[data-node-type="cart-quantity"]') && (e.wrapper.classList.add("updating"), yield e.updateQuantity(t.target.value, t.target.name));
                        });
                        return function (e) {
                            return t.apply(this, arguments);
                        };
                    })()
                ),
                this.form.addEventListener(
                    "click",
                    (function () {
                        var t = d(function* (t) {
                            t.target.matches('[data-node-type="cart-remove-link"]') && (e.wrapper.classList.add("updating"), yield e.updateQuantity(0, t.target.dataset.productId));
                        });
                        return function (e) {
                            return t.apply(this, arguments);
                        };
                    })()
                ),
                this.cartContainerWrapper &&
                    this.cartContainerWrapper.addEventListener("click", (e) => {
                        e.target.contains(this.cartContainer) && this.closeCart();
                    }),
                Udesly.on(
                    "cart-should-be-updated",
                    d(function* () {
                        e.wrapper.classList.add("updating"), yield e.updateCart();
                    })
                ),
                Udesly.on("cart-updated", (e) => {
                    this.updateCartCount(e.item_count || 0),
                        e.total_price &&
                            this.wrapper.querySelectorAll(".w-commerce-commercecartordervalue").forEach((t) => {
                                t.innerHTML = e.total_price;
                            }),
                        e.items && this.updateCartTemplates(e.items),
                        this.wrapper.classList.remove("updating");
                });
        }
        updateQuantity(e, t) {
            var r = this;
            return d(function* () {
                var a = yield fetch(window.Shopify.routes.root + "cart/change.js", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: t, quantity: e }) });
                if (a.ok) {
                    var n = yield r.cleanCartResponse(yield a.json());
                    Udesly.dispatch("cart-updated", n);
                } else {
                    var i = yield a.json();
                    Udesly.dispatch("error", { statusCode: a.status, error: i });
                }
            })();
        }
        updateCartTemplates(e) {
            e.length
                ? ((this.emptyState.style.display = "none"), (this.cartList.innerHTML = e.reduce((e, t) => e + f.render(this.templateFunc, t), "")), (this.cartListWrapper.style.display = ""))
                : ((this.cartListWrapper.style.display = "none"), (this.emptyState.style.display = "")),
                this.wrapper
                    .querySelectorAll('[data-node-type="cart-close-link-icon"]')
                    .forEach(
                        (e) =>
                            (e.innerHTML =
                                '<svg class="close-icon" width="16px" height="16px" viewBox="0 0 16 16"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><g fill-rule="nonzero" fill="#333333"><polygon points="6.23223305 8 0.616116524 13.6161165 2.38388348 15.3838835 8 9.76776695 13.6161165 15.3838835 15.3838835 13.6161165 9.76776695 8 15.3838835 2.38388348 13.6161165 0.616116524 8 6.23223305 2.38388348 0.616116524 0.616116524 2.38388348 6.23223305 8"></polygon></g></g></svg>')
                    );
        }
        cleanCartResponse(t) {
            return d(function* () {
                return (
                    (t.item_count = t.item_count || 0),
                    (t.total_price = u(t.total_price || 0)),
                    (t.items = yield Promise.all(
                        (t.items || []).map(
                            (function () {
                                var t = d(function* (t) {
                                    try {
                                        var r = (yield (yield fetch(window.Shopify.routes.root + "products/" + t.handle + ".js")).json()).variants.find((e) => e.id == t.variant_id);
                                        t.original_price = r.compare_at_price || t.price;
                                    } catch (e) {
                                        console.error(e);
                                    }
                                    for (var a of (t.original_price != t.price ? (t.original_price = u(t.original_price)) : (t.original_price = ""),
                                    (t.price = u(t.price)),
                                    (t.total = u(t.line_price)),
                                    (t.rowTotal = t.total),
                                    (t.id = t.key),
                                    (t.properties =
                                        (function (t) {
                                            for (var r = 1; r < arguments.length; r++) {
                                                var a = null != arguments[r] ? arguments[r] : {};
                                                r % 2
                                                    ? y(Object(a), !0).forEach(function (r) {
                                                          e(t, r, a[r]);
                                                      })
                                                    : Object.getOwnPropertyDescriptors
                                                    ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a))
                                                    : y(Object(a)).forEach(function (e) {
                                                          Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e));
                                                      });
                                            }
                                            return t;
                                        })({}, t.properties) || {}),
                                    t.options_with_values || []))
                                        ("Title" === a.name && "Default Title" === a.value) || ("string" == typeof a.name && a.name.startsWith("_")) || (t.properties[a.name] = a.value);
                                    if (Object.keys(t.properties).length > 0) for (var n in t.properties) n.startsWith("_") && delete t.properties[n];
                                    return (
                                        (t.title = t.product_title),
                                        t.selling_plan_allocation && t.selling_plan_allocation.selling_plan && t.selling_plan_allocation.selling_plan.name && (t.title += " - " + t.selling_plan_allocation.selling_plan.name),
                                        t
                                    );
                                });
                                return function (e) {
                                    return t.apply(this, arguments);
                                };
                            })()
                        )
                    )),
                    window._editUdeslyCartResponse && (t = window._editUdeslyCartResponse(t)),
                    t
                );
            })();
        }
        updateCart() {

          console.log("Update Cart Initiated")
            var e = this;
            return d(function* () {
                var t = yield fetch(window.Shopify.routes.root + "cart.js", { method: "get", credentials: "same-origin" });
                if (t.ok) {
                    var r = yield e.cleanCartResponse(yield t.json());
                    Udesly.dispatch("cart-updated", r);
                } else {
                    var a = yield t.json();
                    Udesly.dispatch("error", { statusCode: t.status, error: a });
                }
            })();
        }
        updateCartCount(e) {
            this.wrapper.querySelectorAll(".w-commerce-commercecartopenlinkcount").forEach((t) => {
                (t.shouldHide = t.shouldHide || "empty" === t.getAttribute("data-count-hide-rule")),
                    void 0 === e && (e = Number(t.textContent) || 0),
                    t.shouldHide && 0 === e ? (t.style.display = "none") : (t.style.display = ""),
                    (t.textContent = e.toString());
            });
        }
        closeCart() {
            this.wrapper.dispatchEvent(new CustomEvent("wf-change-cart-state", { bubbles: 1, detail: { open: !1 } }));
        }
        toggleCart() {
            this.wrapper.dispatchEvent(new CustomEvent("wf-change-cart-state", { bubbles: 1 }));
        }
        openCart() {
            this.wrapper.dispatchEvent(new CustomEvent("wf-change-cart-state", { bubbles: 1, detail: { open: !0 } }));
        }
        handleChangeCartState(e) {
            if (e.currentTarget instanceof Element && e instanceof CustomEvent) {
                var t = e.currentTarget,
                    r = e.detail,
                    a = t.hasAttribute("data-cart-open"),
                    n = r && null != r.open ? r.open : !a,
                    i = c("commerce-cart-container-wrapper", this.wrapper);
                if (i) {
                    var o = c("commerce-cart-container", this.wrapper);
                    if (o) {
                        var s = i.parentElement;
                        if (s) {
                            var l = s.getAttribute("data-wf-cart-type"),
                                d = s.getAttribute("data-wf-cart-duration") || "300ms",
                                u = s.getAttribute("data-wf-cart-easing") || "ease-out-quad",
                                p = "opacity " + d + " ease 0ms",
                                m = "0ms" !== d,
                                h = void 0,
                                f = void 0;
                            switch (l) {
                                case "modal":
                                    (h = { scale: 0.95 }), (f = { scale: 1 });
                                    break;
                                case "leftSidebar":
                                    (h = { x: -30 }), (f = { x: 0 });
                                    break;
                                case "rightSidebar":
                                    (h = { x: 30 }), (f = { x: 0 });
                                    break;
                                case "leftDropdown":
                                case "rightDropdown":
                                    (h = { y: -10 }), (f = { y: 0 });
                            }
                            n
                                ? (t.setAttribute("data-cart-open", ""),
                                  i.style.removeProperty("display"),
                                  m &&
                                      !a &&
                                      (window.Webflow.tram(i).add(p).set({ opacity: 0 }).start({ opacity: 1 }),
                                      window.Webflow.tram(o)
                                          .add("transform " + d + " " + u + " 0ms")
                                          .set(h)
                                          .start(f)))
                                : (t.removeAttribute("data-cart-open"),
                                  m
                                      ? (window.Webflow.tram(i)
                                            .add(p)
                                            .start({ opacity: 0 })
                                            .then(function () {
                                                (i.style.display = "none"), window.Webflow.tram(o).stop();
                                            }),
                                        window.Webflow.tram(o)
                                            .add("transform " + d + " " + u + " 50ms")
                                            .start(h))
                                      : (i.style.display = "none"));
                        }
                    }
                }
            }
        }
    }
    class g {
        constructor(e, t) {
            if (
                ((this.activeClass = "w--ecommerce-pill-selected"),
                (this.group = e),
                (this.form = t),
                (this.name = this.group.getAttribute("aria-label")),
                (this.select = this.form.querySelector('select[name="' + this.name + '"]')),
                !this.select)
            )
                throw Error("Invalid Pills!", e);
            (this.pills = this.group.querySelectorAll(".w-commerce-commerceaddtocartoptionpill")),
                this.select.addEventListener("change", (e) => {
                    this.changeValue(this.select.value);
                }),
                this.changeValue(this.select.value),
                this.pills.forEach((e) => {
                    e.addEventListener("click", (t) => {
                        (this.select.value = e.dataset.optionName), this.select.dispatchEvent(new Event("change", { bubbles: !0 }));
                    });
                });
        }
        changeValue(e) {
            e &&
                this.pills.forEach((t) => {
                    t.dataset.optionName === e ? t.classList.add(this.activeClass) : t.classList.remove(this.activeClass);
                });
        }
    }
    function b(e) {
        var t = document.createElement("textarea");
        return (t.innerHTML = e), t.value;
    }
    class E {
        constructor(e) {
            var t = this;
            if (
                ((this._updatedProps = 0),
                (this.form = e),
                (this.images = []),
                (this.prices = []),
                (this.skus = []),
                (this.barcodes = []),
                (this.unitPrices = []),
                (this.buyButtons = this.form.querySelectorAll('[type="submit"], [data-node-type="commerce-buy-now-button"]')),
                (this.isSingleProduct = document.body.classList.contains("template-product") && !this.form.closest(".w-dyn-item")),
                (this.submit = this.form.querySelector('input[type="submit"]')),
                !this.submit)
            )
                throw Error("Invalid Add to cart");
            (this.normalAddToCartText = this.submit.value || "Add to Cart"),
                (this.loadingAddToCartText = this.submit.dataset.loadingText || "Adding to cart..."),
                this.form.querySelectorAll('[data-node-type="commerce-add-to-cart-error"]').forEach((e) => {
                    e.dataset.wAddToCartGeneralError && (e.textContent = e.dataset.wAddToCartGeneralError);
                }),
                this.form.querySelectorAll('[data-node-type="commerce-buy-now-button"]').forEach((e) => {
                    e.addEventListener(
                        "click",
                        (function () {
                            var e = d(function* (e) {
                                e.preventDefault(), e.target.disabled || (yield t.addItemToCartAndCheckout());
                            });
                            return function (t) {
                                return e.apply(this, arguments);
                            };
                        })()
                    );
                }),
                (this.errorWrapper = this.form.parentElement.querySelector('[data-node-type="commerce-add-to-cart-error"]')),
                (this.outOfStockErrorWrapper = this.form.parentElement.querySelector(".w-commerce-commerceaddtocartoutofstock"));
            try {
                this.variationConfig = JSON.parse(this.form.querySelector("script").textContent);
                var r = this.form.querySelector('[name="id"]');
                if (((this.variation = this.variationConfig[0]), r && r.value)) {
                    var a = this.variationConfig.find((e) => e.id == r.value);
                    a && (this.variation = a);
                }
                if (
                    (this.form.querySelector("select") &&
                        this.form.addEventListener("change", (e) => {
                            e.target.matches("select") && this.changeVariation(e.target);
                        }),
                    this.isSingleProduct && "URLSearchParams" in window)
                ) {
                    var n = new URLSearchParams(window.location.search);
                    if (n.get("variant")) {
                        var i = n.get("variant");
                        i && this.variationConfig.find((e) => e.id == i) && ((this.variation = this.variationConfig.find((e) => e.id == i)), this._updatedProps++);
                    }
                }
                this.alignVariantId(this.variation.id);
                var o = this.form.closest(".w-dyn-item");
                o
                    ? ((this.images = Array.from(o.querySelectorAll('[data-commerce-type="variation-image"]'))),
                      (this.moreImages = Array.from(o.querySelectorAll('[data-commerce-type="more-images"]'))),
                      (this.prices = Array.from(o.querySelectorAll('[data-commerce-type="variation-price"]'))),
                      (this.compareAtPrices = Array.from(o.querySelectorAll('[data-commerce-type="variation-compare_at_price"]'))),
                      (this.skus = Array.from(o.querySelectorAll('[data-commerce-type="variation-sku"]'))),
                      (this.barcodes = Array.from(o.querySelectorAll('[data-commerce-type="variation-barcode"]'))),
                      (this.unitPrices = Array.from(document.querySelectorAll('[data-commerce-type="unit-price"]'))),
                      (this.dimensions = Array.from(document.querySelectorAll('[data-commerce-type="dimensions"]'))))
                    : ((this.moreImages = Array.from(document.querySelectorAll('[data-commerce-type="more-images"]')).filter((e) => !e.closest(".w-dyn-item"))),
                      (this.images = Array.from(document.querySelectorAll('[data-commerce-type="variation-image"]')).filter((e) => !e.closest(".w-dyn-item"))),
                      (this.prices = Array.from(document.querySelectorAll('[data-commerce-type="variation-price"]')).filter((e) => !e.closest(".w-dyn-item"))),
                      (this.compareAtPrices = Array.from(document.querySelectorAll('[data-commerce-type="variation-compare_at_price"]')).filter((e) => !e.closest(".w-dyn-item"))),
                      (this.unitPrices = Array.from(document.querySelectorAll('[data-commerce-type="unit-price"]')).filter((e) => !e.closest(".w-dyn-item"))),
                      (this.skus = Array.from(document.querySelectorAll('[data-commerce-type="variation-sku"]')).filter((e) => !e.closest(".w-dyn-item"))),
                      (this.dimensions = Array.from(document.querySelectorAll('[data-commerce-type="dimensions"]')).filter((e) => !e.closest(".w-dyn-item"))),
                      (this.barcodes = Array.from(document.querySelectorAll('[data-commerce-type="variation-barcode"]')).filter((e) => !e.closest(".w-dyn-item")))),
                    this.moreImages.forEach((e) => {
                        var t = e.querySelector("template");
                        t &&
                            ((e.templateEmpty = t.content.querySelector(".w-dyn-empty").cloneNode(!0)),
                            (e.templateList = t.content.querySelector(".w-dyn-items").cloneNode(!1)),
                            (e.templateItem = t.content.querySelector(".w-dyn-item").cloneNode(!0)));
                    }),
                    this.alignSelect(),
                    this.updateVariationProps();
            } catch (e) {
                console.error(e), console.error("Missing necessary data for Add to Cart!", this.form);
            }
            var s = this.form.querySelectorAll(".w-commerce-commerceaddtocartoptionpillgroup");
            s.forEach((e) => {
                new g(e, this.form);
            }),
                1 == s.length &&
                    this.variationConfig.forEach((e) => {
                        e.available ||
                            this.form.querySelectorAll('[data-option-name="'.concat(e.option1, '"]')).forEach((e) => {
                                e.classList.add("w--ecommerce-pill-disabled");
                            });
                    }),
                this.form.addEventListener(
                    "submit",
                    (function () {
                        var e = d(function* (e) {
                            e.preventDefault(), 
                            e.stopPropagation(), 
                            console.log("submit event listener called"), // debug statement
                            yield t.addItemToCart(); 
                        });
                        return function (t) {
                            return e.apply(this, arguments);
                        };
                    })()
                );
        }
        alignVariantId(e) {
            if (e) this.form.querySelector('[name="id"]').value = e;
            else {
                e = this.form.querySelector('[name="id"]').value;
                var t = this.variationConfig.find((t) => t.id === e);
                t && ((this.variation = t), this.alignSelect(), this.updateVariationProps());
            }
            if (this.isSingleProduct && "URLSearchParams" in window) {
                var r = new URLSearchParams(window.location.search);
                r.set("variant", e);
                var a = window.location.pathname + "?" + r.toString();
                history.replaceState(null, "", a);
            }
        }
        alignSelect() {
            if (this.variation)
                for (var e = 1; e <= 3; e++) {
                    var t = "option".concat(e);
                    if (this.variation[t]) {
                        var r = this.form.querySelector('select[name="'.concat(t, '"]'));
                        r && (r.value = this.variation[t]);
                    }
                }
        }
        changeVariation() {
            var e = new FormData(this.form),
                t = e.get("option1") || "",
                r = e.get("option2") || "",
                a = e.get("option3") || "",
                n = this.variationConfig.find((e) => e.option1 === t && e.option2 === r && e.option3 == a);
            n
                ? ((this.variation = n),
                  this.buyButtons.forEach((e) => {
                      (e.disabled = !1), e.classList.remove("disabled");
                  }),
                  this.alignVariantId(this.variation.id),
                  this.updateVariationProps())
                : this.buyButtons.forEach((e) => {
                      (e.disabled = !0), e.classList.add("disabled");
                  });
        }
        updateVariationProps() {
            requestAnimationFrame(() => {
                this._updateVariationProps(), this._updatedProps++;
            });
        }
        _updateVariationProps() {
            document.body.dispatchEvent(new CustomEvent("foundVariation", { detail: { variation: this.variation, element: this.form } }));
            var e = this.variation.featured_image,
                t = this.variation.more_images;
            this.skus.forEach((e) => {
                e.textContent = this.variation.sku;
            }),
                this.barcodes.forEach((e) => {
                    e.textContent = this.variation.barcode;
                }),
                this.variation.available
                    ? (this.form.classList.remove("out-of-stock"),
                      this.form.parentElement.querySelectorAll(".w-commerce-commerceaddtocartoutofstock").forEach((e) => {
                          e.style.display = "none";
                      }),
                      this.buyButtons.forEach((e) => {
                          (e.disabled = !1), e.classList.remove("disabled", "out-of-stock");
                      }))
                    : (this.form.classList.add("out-of-stock"),
                      this.form.parentElement.querySelectorAll(".w-commerce-commerceaddtocartoutofstock").forEach((e) => {
                          e.style.display = "";
                      }),
                      this.buyButtons.forEach((e) => {
                          (e.disabled = !0), e.classList.add("disabled", "out-of-stock");
                      })),
                this.dimensions.forEach((e) => {
                    switch (e.dataset.type) {
                        case "width":
                            e.textContent = this.variation.width;
                            break;
                        case "height":
                            e.textContent = this.variation.height;
                            break;
                        case "length":
                            e.textContent = this.variation.length;
                    }
                }),
                this._updatedProps > 0 &&
                    e &&
                    0 == !this._updatedProps &&
                    this.images.forEach((t) => {
                        if (("IMG" === t.tagName ? ((t.src = e), t.removeAttribute("srcset")) : (t.style.backgroundImage = "url(".concat(e, ")")), t.closest(".w-lightbox"))) {
                            var r = t.closest(".w-lightbox").querySelector("script");
                            if (r) {
                                var a = JSON.parse(r.textContent);
                                a.items && a.items[0] && (a.items[0].url = e), (r.textContent = JSON.stringify(a));
                            }
                            var n = Webflow.require("lightbox");
                            n && n.ready();
                        }
                    }),
                this.moreImages && this.moreImages.length && this.updateMoreImages(t),
                this.unitPrices.forEach((e) => {
                    e.innerHTML = b(this.variation.unit_price);
                }),
                this.prices.forEach((e) => {
                    e.innerHTML = b(this.variation.price);
                }),
                this.compareAtPrices.forEach((e) => {
                    this.variation.compare_at_price ? ((e.innerHTML = this.variation.compare_at_price), (e.style.display = "")) : (e.style.display = "none");
                }),
                this.form.dispatchEvent(new CustomEvent("variation_found", { detail: { variation: this.variation } }));
        }
        updateMoreImages(e) {
            Array.isArray(e) || (e = []),
                this.moreImages.forEach((t) => {
                    if (t.templateEmpty && t.templateList && t.templateItem) {
                        if (!t.templateItemFunction) {
                            var r = t.templateItem.cloneNode(!0).outerHTML.replace(/{#(.*?)#}/gm, function (e, t) {
                                return (t = t.trim().replace("setItem", "item").replace("['more-images']", ".src").replace("more-images", "src")), "${".concat(t, "}");
                            });
                            t.templateItemFunction = new Function("item", "return `" + r + "`;");
                        }
                        if (((t.innerHTML = ""), e.length)) {
                            var a = t.templateList.cloneNode(),
                                n = "";
                            for (var i of e) n += t.templateItemFunction(i);
                            (a.innerHTML = n), t.append(a);
                            var o = Webflow.require("lightbox");
                            o && o.ready();
                        } else t.append(t.templateEmpty.cloneNode(!0));
                    } else console.error("Invalid Template More Images");
                });
        }
        addItemToCartAndCheckout() {
            var e = this;
            return d(function* () {
                (yield e.addItemToCart(!1)) && (window.location = window.Shopify.routes.root + "checkout");
            })();
        }

      //Buji Boy
        addItemToCart() {
          
         if (eventHandled % 2 != 0){
           eventHandled = 2; 
         }
            var e = arguments,
                t = this;
            return d(function* () {
                var r = !(e.length > 0 && void 0 !== e[0]) || e[0];
                try {
                    t.errorWrapper && (t.errorWrapper.style.display = "none"), t.outOfStockErrorWrapper && (t.outOfStockErrorWrapper.style.display = "none");
                    var a = Object.fromEntries(new FormData(t.form).entries());
                    for (var n in ((a.quantity = a.quantity ? a.quantity : 1), a))
                        if (n.includes("properties[")) {
                            a.properties || (a.properties = {});
                            var i = n.replace("properties[", "").replace("]", "");
                            "" !== a[n] && (a.properties[i] = a[n]), delete a[n];
                        }
                    t.submit.value = t.loadingAddToCartText;
                   console.log("HIIII")
                    var o = yield fetch(window.Shopify.routes.root + "cart/add.js", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ items: [a] }) });
                    if (((t.submit.value = t.normalAddToCartText), 200 != o.status)) {
                        var s = (yield o.json()).description;
                        throw (t.errorWrapper && (t.errorWrapper.lastElementChild.textContent = s), new Error(s));
                    }
                    return (t.submit.value = t.normalAddToCartText), Udesly.dispatch("product-added", r), !0;
                } catch (e) {
                    return (
                        t.errorWrapper &&
                            ((t.errorWrapper.style.display = ""),
                            setTimeout(() => {
                                t.errorWrapper.style.display = "none";
                            }, 5e3)),
                        console.error(e),
                        !1
                    );
                }
            })();
        }
    }
    function S(e) {
        return new Promise(function (t, r) {
            (e.oncomplete = e.onsuccess = function () {
                return t(e.result);
            }),
                (e.onabort = e.onerror = function () {
                    return r(e.error);
                });
        });
    }
    function _(e, t) {
        var r,
            a = (!navigator.userAgentData && /Safari\//.test(navigator.userAgent) && !/Chrom(e|ium)\//.test(navigator.userAgent) && indexedDB.databases
                ? new Promise(function (e) {
                      var t = function () {
                          return indexedDB.databases().finally(e);
                      };
                      (r = setInterval(t, 100)), t();
                  }).finally(function () {
                      return clearInterval(r);
                  })
                : Promise.resolve()
            ).then(function () {
                var r = indexedDB.open(e);
                return (
                    (r.onupgradeneeded = function () {
                        return r.result.createObjectStore(t);
                    }),
                    S(r)
                );
            });
        return function (e, r) {
            return a.then(function (a) {
                return r(a.transaction(t, e).objectStore(t));
            });
        };
    }
    function A() {
        return v || (v = _("keyval-store", "keyval")), v;
    }
    function C(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : A();
        return t("readonly", function (t) {
            return S(t.get(e));
        });
    }
    function x(e, t) {
        var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : A();
        return r("readwrite", function (r) {
            return r.put(t, e), S(r.transaction);
        });
    }
    var q = _("udesly-recommendeds", "db"),
        P = (function e(t) {
            for (var r = [], a = 0; a < t.childNodes.length; a++) {
                var n = t.childNodes[a];
                8 === n.nodeType ? r.push(n) : r.push.apply(r, e(n));
            }
            return r;
        })(document),
        L = (function () {
            var e = d(function* (e, t) {
                return yield x(e, t, q);
            });
            return function (t, r) {
                return e.apply(this, arguments);
            };
        })(),
        k = (function () {
            var e = d(function* (e) {
                return yield C(e, q);
            });
            return function (t) {
                return e.apply(this, arguments);
            };
        })(),
        O = (function () {
            var e = d(function* () {
                var e = (function () {
                    try {
                        var e, t;
                        return P[1] && null !== (e = P[1].nodeValue) && void 0 !== e && e.includes("Last Published")
                            ? new Date(P[1].nodeValue.replace("Last Published:", "").trim()).getTime()
                            : P[0] && null !== (t = P[0].nodeValue) && void 0 !== t && t.includes("Last Published")
                            ? new Date(P[0].nodeValue.replace("Last Published:", "").trim()).getTime()
                            : Date.now() - 9e5;
                    } catch (e) {
                        return Date.now() - 9e5;
                    }
                })();
                ((yield C("__init", q)) || 0) + 3e5 < e &&
                    (yield (function () {
                        return (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : A())("readwrite", function (e) {
                            return e.clear(), S(e.transaction);
                        });
                    })(q),
                    yield x("__init", e, q));
            });
            return function () {
                return e.apply(this, arguments);
            };
        })(),
        T = (e) => {
            if (e.querySelector(".w-dyn-item [data-ix]") || e.querySelector(".w-dyn-item form"))
                try {
                    window.Webflow.destroy(), window.Webflow.ready();
                } catch (e) {}
            if (e.querySelector('[data-animation-type="lottie"]'))
                try {
                    window.Webflow.require("lottie").init();
                } catch (e) {}
            if (e.querySelector("[data-w-id]"))
                try {
                    var t = window.Webflow.require("ix2");
                    t && (t.init(), document.dispatchEvent(new Event("IX2_PAGE_UPDATE")));
                } catch (e) {}
            if (e.querySelector(".w-dyn-item .w-lightbox"))
                try {
                    window.Webflow.require("lightbox").ready();
                } catch (e) {}
            if (e.querySelector(".w-dyn-item .w-dropdown"))
                try {
                    window.Webflow.require("dropdown").ready();
                } catch (e) {}
            if (
                (e.querySelector(".w-dyn-item .w-commerce-commerceaddtocartbutton") &&
                    setTimeout(() => {
                        window.dispatchEvent(new CustomEvent("wf-render-tree", { detail: { isInitial: !0 } }));
                    }),
                window.MemberStack) &&
                e.querySelector(".w-dyn-item") &&
                Array.from(e.querySelector(".w-dyn-item").querySelectorAll("*")).some((e) => Array.from(e.attributes).some((e) => e.name.startsWith("ms-")))
            )
                try {
                    window.MemberStack.reload();
                } catch (e) {}
            window.Webflow.require("ix2") && window.Webflow.require("ix2").init(), "complete" == document.readyState && document.dispatchEvent(new Event("readystatechange"));
        };
    class j {
        constructor(e) {
            (this.el = e), (this.id = e.getAttribute("shopify-recommended")), (this.limit = Number(e.getAttribute("limit")) || 4);
        }
        init() {
            var e = this;
            return d(function* () {
                var { products: t } = yield (yield fetch("/recommendations/products.json?product_id=".concat(e.id, "&limit=").concat(e.limit))).json();
                if (((t && t.length) || (window._recommendedProducts && Array.isArray(window._recommendedProducts) && "string" == typeof (t = window._recommendedProducts)[0] && (t = t.map((e) => ({ handle: e })))), t && t.length)) {
                    var r = yield Promise.all(t.map((t) => e.fetchProductHTML(t.handle))),
                        a = document.createDocumentFragment();
                    r.forEach((e) => {
                        var t = document.createElement("div");
                        (t.innerHTML = e), t.firstElementChild && a.append(t.firstElementChild);
                    }),
                        e.el.querySelector(".w-dyn-items").append(a),
                        Udesly.dispatch("refetch-add-to-carts"),
                        T(e.el),
                        Udesly.dispatch("webflow-restarted"),
                        document.body.classList.add("has-recommendeds");
                } else e.el.querySelectorAll(".w-dyn-empty").forEach((e) => (e.style.display = "")), Udesly.dispatch("refetch-add-to-carts"), T(e.el), Udesly.dispatch("webflow-restarted"), document.body.classList.add("no-recommendeds");
            })();
        }
        fetchProductHTML(e) {
            return d(function* () {
                var t = yield k(e + "_html");
                if (t) return t;
                try {
                    var r = yield fetch("/products/".concat(e, "?view=sh_recommended"));
                    if (r.ok) {
                        var a = yield r.text();
                        return yield L(e + "_html", a), a;
                    }
                    return "";
                } catch (e) {
                    return "";
                }
            })();
        }
    }
    function I(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var a = Object.getOwnPropertySymbols(e);
            t &&
                (a = a.filter(function (t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })),
                r.push.apply(r, a);
        }
        return r;
    }
    function W(t) {
        for (var r = 1; r < arguments.length; r++) {
            var a = null != arguments[r] ? arguments[r] : {};
            r % 2
                ? I(Object(a), !0).forEach(function (r) {
                      e(t, r, a[r]);
                  })
                : Object.getOwnPropertyDescriptors
                ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a))
                : I(Object(a)).forEach(function (e) {
                      Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e));
                  });
        }
        return t;
    }
    Udesly.on("error", console.error),
        s("commerce-cart-wrapper").forEach((e) => {
            new w(e);
        }),
        s("commerce-add-to-cart-form").forEach((e) => {
            e.dataset.udeslyInit || (new E(e), (e.dataset.udeslyInit = "true"));
        }),
        Udesly.on("refetch-add-to-carts", () => {
            s("commerce-add-to-cart-form").forEach((e) => {
                e.dataset.udeslyInit || (new E(e), (e.dataset.udeslyInit = "true"));
            });
        }),
        Udesly.dispatch("cart-should-be-updated");
    var N = document.createElement("style");
    (N.textContent = "body .shopify-cleanslate ul li[data-testid] {\n    flex-basis: 100%!important;\n    margin-bottom: 15px!important;\n} .shopify-policy__container { max-width: unset!important; }"),
        document.head.append(N),
        document.body.classList.contains("template-customers-order") &&
            document.querySelectorAll('[data-node-type="commerce-order-confirmation-wrapper"] [data-wf-collection="database.commerceOrder.userItems"]').forEach((e) => {
                var t = e.getAttribute("data-wf-template-id"),
                    r = document.querySelector("#".concat(t)),
                    a = e.querySelector('script[type="application/json"]').textContent;
                if (r && a) {
                    var n = f.compile(r.textContent),
                        i = JSON.parse(a),
                        o = document.createDocumentFragment(),
                        s = document.createElement("div");
                    for (var c of (o.append(s), i)) {
                        for (var l of ((c.quantity = c.quantity || 1), (c.rowTotal = c.total), (c.count = c.quantity), (c.id = c.title), (c.properties = W({}, c.properties) || {}), c.options || []))
                            ("Title" === l.name && "Default Title" === l.value) || ("string" == typeof l.name && l.name.startsWith("_")) || (c.properties[l.name] = l.value);
                        if (Object.keys(c.properties).length > 0) for (var d in c.properties) d.startsWith("_") && delete c.properties[d];
                        var u = document.createElement("div");
                        s.append(u), (u.outerHTML = f.render(n, c));
                    }
                    e.append(o.firstElementChild);
                }
            }),
        document.querySelectorAll("[shopify-recommended]").length && window.Webflow.require("ix2") && window.Webflow.require("ix2").destroy(),
        O().then(
            document.querySelectorAll("[shopify-recommended]").forEach((e) => {
                new j(e).init();
            })
        ),
        document.querySelectorAll(".w-dyn-items[custom-sort]").forEach((e) => {
            var t = JSON.parse(e.getAttribute("custom-sort")),
                r = Array.from(e.children),
                a = [];
            r.forEach((e, r) => {
                var n = e.getAttribute("custom-sort-field");
                switch (t.type) {
                    case "Bool":
                        n = !!n;
                        break;
                    case "Number":
                        n = Number(n);
                }
                var i = { index: r, value: n };
                a.push(i);
            }),
                a
                    .sort((e, r) => (t.reversed ? (e.value > r.value ? 1 : -1) : e.value > r.value ? -1 : 1))
                    .forEach((t) => {
                        e.append(r[t.index]);
                    });
        }),
        (window.Webflow = window.Webflow || []),
        window.Webflow.push(() => {
            document.querySelectorAll(".udy-tag-current").forEach((e) => e.classList.add("w--current")), document.querySelectorAll(".udy-tag-not-current").forEach((e) => e.classList.remove("w--current"));
        }),
        document.querySelectorAll('a[href="/checkout"]').forEach((e) => (e.href = window.Shopify.routes.root + "checkout"));
})();
