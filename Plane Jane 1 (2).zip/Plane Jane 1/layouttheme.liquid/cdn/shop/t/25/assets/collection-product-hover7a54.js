/** Shopify CDN: Minification failed

Line 13:147 Transforming let to the configured target environment ("es5") is not supported yet
Line 13:369 Transforming let to the configured target environment ("es5") is not supported yet
Line 13:448 Transforming let to the configured target environment ("es5") is not supported yet
Line 13:584 Transforming let to the configured target environment ("es5") is not supported yet
Line 13:767 Transforming let to the configured target environment ("es5") is not supported yet
Line 13:925 Transforming let to the configured target environment ("es5") is not supported yet
Line 13:1079 Transforming let to the configured target environment ("es5") is not supported yet
Line 13:1321 Transforming let to the configured target environment ("es5") is not supported yet

**/
function handleViewportChange(){window.innerWidth>768?attachHoverEventListeners():attachSwipeEventListeners()}function attachHoverEventListeners(){let e=document.querySelectorAll(".collection-product-container");e.forEach(e=>{e.addEventListener("mouseover",handleProductHover),e.addEventListener("mouseout",handleProductHoverOut)})}function attachSwipeEventListeners(){let e=document.querySelectorAll(".collection-product-container");e.forEach(e=>{let t=null,i=null;e.addEventListener("touchstart",e=>{t=e.touches[0].clientX,i=e.touches[0].clientY}),e.addEventListener("touchend",l=>{let n=l.changedTouches[0].clientX,r=l.changedTouches[0].clientY,o=n-t,s=Math.abs(r-i);o>50&&s<20?showPreviousImage(e):o<-50&&s<20&&showNextImage(e)})})}function handleProductHover(e){let t=e.currentTarget.querySelectorAll("img");t.length>=2&&(t[0].style.visibility="hidden",t[1].style.visibility="visible")}function handleProductHoverOut(e){let t=e.currentTarget.querySelectorAll("img");t.length>=2&&(t[0].style.visibility="visible",t[1].style.visibility="hidden")}function showPreviousImage(e){let t=e.querySelectorAll("img");t.length>=2&&(t[0].style.visibility="visible",t[1].style.visibility="hidden",t[0].style.opacity="1",t[1].style.opacity="0",t[0].style.filter="blur(0px)",t[1].style.filter="blur(5px)")}function showNextImage(e){let t=e.querySelectorAll("img");t.length>=2&&(t[1].style.visibility="visible",t[0].style.opacity="0",t[1].style.opacity="1",t[0].style.filter="blur(5px)",t[1].style.filter="blur(0px)")}window.addEventListener("load",handleViewportChange),window.addEventListener("resize",handleViewportChange);
